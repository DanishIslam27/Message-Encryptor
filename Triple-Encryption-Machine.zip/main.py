import time

print(">>> An Encryption Program designed by Danish Islam")
print()
print(">>> 😠 😖😄😞😖😟😩😡😞😍😭😟😱😖😊😡😁😩😁🙁😟😍😖😭😩😁😆😭😩😢😍😩😢😍😆😭")
time.sleep(1)
print(">>> *89& 9& *85 *^9$=5 5@3^?$*9#@ $^#7^1!")
time.sleep(1)
print(">>> This is the triple encryption program")
time.sleep(1)
print()
print("---------------------------------------------------------")
print()

#variables 
keys = "abcdefghijklmnopqrstuvwxyz !"
values = "1234567890-=!@#$%^&*()_+?; "
values2 = " 🙂😊😀😁😃😄😆😍☹️🙁😠😡😞😟😣😖😢😭😂😨😧😦😱😫😩"

# dictionaries for encryption
DictEncryptA = dict(zip(keys, values))
DictEncryptB = dict(zip(values, values2))

#dictionaries for decryption
DictDecryptB = dict(zip(values2, values))
DictDecryptA = dict(zip(values, keys))

#user input 'the message' and mode
message = input(">>> Enter your message: ")
mode = input(">>> Enter the mode, (e) for encrypt and (d) for decrypt: ")

# run encode or decode
if mode == "e":
  NewMessage1 = "".join([DictEncryptA[letter] for letter in message.lower()])
  NewMessage2 = "".join([DictEncryptB[letter] for letter in NewMessage1.lower()])
  NewMessage3 = NewMessage2[::-1]
  print()
  print(">>> Your encrypted message is: " + NewMessage3.title())
elif mode == "d":
  NewMessage1 = message[::-1]
  NewMessage2 = "".join([DictDecryptB[letter] for letter in NewMessage1.lower()])
  NewMessage3 = "".join([DictDecryptA[letter] for letter in NewMessage2.lower()])
  print()
  print(">>> Your decrypted message is: " + NewMessage3.title())









